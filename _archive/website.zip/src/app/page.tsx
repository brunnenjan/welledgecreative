// src/app/page.tsx
import Header from "../components/Header";
import BucketHero from "../components/BucketHero";

export default function Home() {
  return (
    <main className="relative">
      <Header />
      <BucketHero />

      {/* Leistungen (erste Content‑Section) */}
      <section id="leistungen" className="relative z-60 bg-background text-foreground">
        <div className="mx-auto max-w-5xl px-6 py-20 md:py-28">
          <h2 className="text-3xl md:text-4xl font-semibold tracking-tight text-accent">
            Leistungen
          </h2>
          <p className="mt-4 text-lg">
            Wir liefern schlüssiges Branding, präzises Design und performante Webseiten aus einer Hand.
          </p>
          {/* Unterbereiche wie Branding, Webdesign, etc. hier rein */}
        </div>
      </section>

      {/* Weitere Sektionen wie "About", "Kontakt" können analog eingefügt werden */}
    </main>
  );
}
