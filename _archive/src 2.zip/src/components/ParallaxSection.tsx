// src/components/ParallaxSection.tsx
"use client";

import { useEffect, useRef } from "react";
import Image from "next/image";

type Props = {
  // Asset paths
  bgSrc: string;
  fgSrc: string;
  bucketSrc?: string;

  // Display options
  showBucket?: boolean;
  showRope?: boolean;
  bucketFlipX?: boolean;

  // Layout
  sectionHeight?: number; // vh units
  bucketStartOffset?: number; // vh from top
  fgOverscan?: number; // vh extra height to prevent gaps

  // Parallax speeds (multiplier of scroll distance)
  bgSpeed?: number; // positive = moves down
  fgSpeed?: number; // negative = moves up
  bucketSpeed?: number; // positive = moves down

  // Bucket sizing
  bucketSize?: number; // scale multiplier
};

export default function ParallaxSection({
  bgSrc,
  fgSrc,
  bucketSrc = "/bucket-rope-long-angled.png",
  showBucket = false,
  showRope = true,
  bucketFlipX = false,
  sectionHeight = 80,
  bucketStartOffset = -12,
  fgOverscan = 30,
  bgSpeed = 0.15,
  fgSpeed = -0.35,
  bucketSpeed = 0.25,
  bucketSize = 1.0,
}: Props) {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const fgRef = useRef<HTMLDivElement>(null);
  const bucketRef = useRef<HTMLDivElement>(null);

  // Responsive bucket height calculation
  const BUCKET_MIN_PX = 180 * bucketSize;
  const BUCKET_MID_VH = 32 * bucketSize;
  const BUCKET_MAX_PX = 520 * bucketSize;
  const bucketHeight = `clamp(${BUCKET_MIN_PX}px, ${BUCKET_MID_VH}vh, ${BUCKET_MAX_PX}px)`;

  useEffect(() => {
    const section = sectionRef.current;
    const bg = bgRef.current;
    const fg = fgRef.current;
    const bucket = bucketRef.current;

    if (!section || !bg || !fg) return;

    let ticking = false;

    const updateParallax = () => {
      ticking = false;
      
      const rect = section.getBoundingClientRect();
      const scrollProgress = -rect.top; // Positive when section enters viewport

      // Apply parallax transforms
      bg.style.transform = `translate3d(0, ${scrollProgress * bgSpeed}px, 0)`;
      fg.style.transform = `translate3d(0, ${scrollProgress * fgSpeed}px, 0)`;
      
      if (bucket && showBucket) {
        bucket.style.transform = `translate3d(-50%, ${scrollProgress * bucketSpeed}px, 0)`;
      }
    };

    const onScroll = () => {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(updateParallax);
      }
    };

    // Check for reduced motion preference
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (!prefersReducedMotion) {
      updateParallax();
      window.addEventListener("scroll", onScroll, { passive: true });
      window.addEventListener("resize", onScroll);
    }

    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [bgSpeed, fgSpeed, bucketSpeed, showBucket]);

  // Add subtle bucket swing animation
  useEffect(() => {
    if (!showBucket || !bucketRef.current) return;

    const bucket = bucketRef.current;
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (prefersReducedMotion) return;

    // Add CSS animation inline
    bucket.style.animation = "bucket-swing 3.5s ease-in-out infinite alternate";
  }, [showBucket]);

  return (
    <section
      ref={sectionRef}
      className="relative overflow-hidden bg-black"
      style={{ height: `${sectionHeight}vh`, minHeight: "400px" }}
    >
      {/* Background Layer */}
      <div
        ref={bgRef}
        className="absolute inset-0 z-0 will-change-transform"
        style={{
          backgroundImage: `url(${bgSrc})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          opacity: 0.92,
        }}
      />

      {/* Bucket with Rope (optional) */}
      {showBucket && (
        <div
          ref={bucketRef}
          className="absolute left-1/2 z-20 pointer-events-none will-change-transform"
          style={{ 
            top: `${bucketStartOffset}vh`,
            transformOrigin: "top center"
          }}
          aria-hidden
        >
          {/* Rope Extension */}
          {showRope && (
            <div
              className="absolute left-1/2 -translate-x-1/2"
              style={{
                bottom: "100%",
                width: "3px",
                height: "120vh",
                background: "linear-gradient(to bottom, rgba(204,204,187,0.85), rgba(135,118,102,0.85))",
                opacity: 0.9,
              }}
            />
          )}

          {/* Bucket Image */}
          <Image
            src={bucketSrc}
            alt=""
            width={0}
            height={0}
            sizes="100vw"
            style={{
              height: bucketHeight,
              width: "auto",
              maxWidth: "min(45vw, 600px)",
              display: "block",
              transform: bucketFlipX ? "scaleX(-1)" : undefined,
              filter: "drop-shadow(0 4px 12px rgba(0,0,0,0.4))",
            }}
            priority={false}
          />
        </div>
      )}

      {/* Foreground Cutout Layer */}
      <div
        ref={fgRef}
        className="pointer-events-none absolute inset-0 z-30 will-change-transform"
        style={{ 
          height: `calc(100% + ${fgOverscan}vh)`,
        }}
      >
        <Image
          src={fgSrc}
          alt=""
          fill
          sizes="100vw"
          style={{ objectFit: "cover" }}
          priority={false}
        />
      </div>

      {/* Add inline keyframes for bucket swing */}
      <style jsx>{`
        @keyframes bucket-swing {
          0% {
            transform: translate3d(-50%, 0, 0) rotate(-1deg);
          }
          100% {
            transform: translate3d(-50%, 0, 0) rotate(1deg);
          }
        }
      `}</style>
    </section>
  );
}