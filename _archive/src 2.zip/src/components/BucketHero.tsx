// src/components/BucketHero.tsx
"use client";

import { useLayoutEffect, useRef } from "react";
import Image from "next/image";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function BucketHero() {
  const heroRef   = useRef<HTMLElement>(null);
  const pinRef    = useRef<HTMLDivElement>(null);
  const bgRef     = useRef<HTMLDivElement>(null);
  const fgRef     = useRef<HTMLDivElement>(null);
  const bucketRef = useRef<HTMLDivElement>(null);

  // Werte: FG etwas höher, BG sanft, lange Scrollstrecke
  const FG_VH = 72;       // Foreground‑Verschiebung nach oben
  const BG_VH = 4;        // Background leicht nach unten
  const END_FACTOR = 1.35; 
  const OVERSCAN = 32;

  const BUCKET_TRAVEL_VH = 70;
  const BUCKET_SWING_X   = 10;
  const BUCKET_SWING_ROT = 1.1;
  const BUCKET_SWING_DUR = 3.5;

  const vh = (v: number) =>
    typeof window !== "undefined" ? window.innerHeight * (v / 100) : 0;

  useLayoutEffect(() => {
    if (!heroRef.current || !pinRef.current || !bgRef.current || !fgRef.current || !bucketRef.current) return;

    let ctx: gsap.Context | null = null;

    const ready = async () => {
      // Bilder laden abwarten
      const imgs = [bgRef.current, fgRef.current].map((ref) =>
        Array.from(ref!.querySelectorAll("img"))
      ).flat();
      await Promise.allSettled(
        imgs.map(
          (img) =>
            new Promise<void>((resolve) => {
              const el = img as HTMLImageElement;
              if (el.complete) return resolve();
              el.addEventListener("load", () => resolve(), { once: true });
              el.addEventListener("error", () => resolve(), { once: true });
            })
        )
      );
    };

    (async () => {
      await ready();
      ctx = gsap.context(() => {
        const tl = gsap.timeline({
          scrollTrigger: {
            trigger: heroRef.current!,
            start: "top top",
            end: () => `+=${Math.round(window.innerHeight * END_FACTOR)}`,
            scrub: true,
            pin: pinRef.current!,
            pinType: "transform",
            pinSpacing: false,
            anticipatePin: 1,
            invalidateOnRefresh: true,
          },
        });
        // Parallax für BG und FG
        tl.to(bgRef.current!, { y: () => vh(BG_VH), ease: "none" }, 0);
        tl.to(fgRef.current!, { y: () => -vh(FG_VH), ease: "none" }, 0);
        // Eimer fährt runter
        tl.to(bucketRef.current!, { y: () => vh(BUCKET_TRAVEL_VH), ease: "none" }, 0.05);
        // Eimer schwingen
        gsap.to(bucketRef.current!, {
          x: BUCKET_SWING_X,
          rotation: BUCKET_SWING_ROT,
          transformOrigin: "top center",
          duration: BUCKET_SWING_DUR,
          ease: "sine.inOut",
          yoyo: true,
          repeat: -1,
        });
      }, pinRef);
      ScrollTrigger.refresh();
    })();

    return () => {
      ctx?.revert();
    };
  }, []);

  return (
    <header ref={heroRef} className="relative h-[100vh] overflow-hidden bg-background z-0">
      <div ref={pinRef} className="relative h-full w-full will-change-transform">
        {/* Background-Ebene */}
        <div ref={bgRef} className="absolute inset-0 z-0 will-change-transform">
          <Image
            src="/well_deep_down_2.jpg"
            alt=""
            fill
            priority
            className="object-cover opacity-95"
          />
        </div>
        {/* Text */}
        <div className="absolute inset-0 z-20 grid place-items-center text-center px-6">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-6xl font-extrabold leading-tight text-foreground">
              <span className="text-accent">Story-driven</span> Branding & Webdesign
            </h1>
            <p className="mt-4 text-foreground/80">
              Klare Strategie, starke Story, spürbares Erlebnis – vom Logo bis zur Website.
            </p>
            <a
              href="#leistungen"
              className="btn-accent mt-6 inline-block"
            >
              Leistungen ansehen
            </a>
          </div>
        </div>
        {/* Eimer */}
        <div
          ref={bucketRef}
          className="absolute left-1/2 z-40 -translate-x-1/2 pointer-events-none will-change-transform"
          style={{ top: "-14vh", width: "max-content" }}
          aria-hidden
        >
          <Image
            src="/bucket-rope-long-angled.png"
            alt=""
            width={0}
            height={0}
            sizes="100vw"
            style={{ height: "clamp(390px, 75vh, 960px)", width: "auto", display: "block" }}
            priority
          />
        </div>
        {/* Foreground-Cutout */}
        <div
          ref={fgRef}
          className="pointer-events-none absolute left-0 right-0 top-0 z-50 will-change-transform"
          style={{ height: `calc(100% + ${OVERSCAN}px)` }}
        >
          <Image
            src="/foreground_Startingpage.png"
            alt=""
            fill
            priority
            className="object-cover"
          />
        </div>
      </div>
    </header>
  );
}
