// src/components/Header.tsx
"use client";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/",         label: "Start" },
  { href: "/#leistungen", label: "Leistungen" },
  { href: "/#about",   label: "Über uns" },
  { href: "/#kontakt", label: "Kontakt" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const wrapper = scrolled
    ? "bg-black/70 backdrop-blur text-foreground"
    : "bg-white text-background";

  return (
    <header className={`fixed inset-x-0 top-0 z-[100] transition-colors ${wrapper}`}>
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2">
          <Image
            src="/Logo Well Edge2-16.png"
            alt="Well Edge Creative"
            width={40}
            height={40}
            priority
          />
          <span className="font-semibold tracking-tight">WELL EDGE CREATIVE</span>
        </Link>
        <ul className="hidden md:flex items-center gap-2">
          {LINKS.map(({ href, label }) => (
            <li key={href}>
              <a
                href={href}
                className={`px-3 py-2 font-medium hover:text-accent ${
                  pathname === href ? "text-accent" : ""
                }`}
              >
                {label}
              </a>
            </li>
          ))}
        </ul>
        <a href="/#kontakt" className="btn-accent">
          Jetzt buchen
        </a>
      </nav>
    </header>
  );
}
