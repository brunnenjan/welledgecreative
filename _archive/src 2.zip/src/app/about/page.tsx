'use client';
import { useEffect, useRef } from 'react';
import { getGsap } from '@/lib/gsap';

export default function About() {
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    const { gsap, ScrollTrigger } = getGsap();
    if (!root.current) return;

    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.reveal').forEach((el) => {
        gsap.from(el, {
          y: 40,
          autoAlpha: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: el,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        });
      });
    }, root);

    return () => ctx.revert();
  }, []);

  return (
    <section id="about" ref={root} className="border-t bg-white">
      <div className="mx-auto max-w-6xl px-4 py-20">
        <h2 className="reveal text-3xl md:text-4xl font-semibold tracking-tight">Über mich</h2>
        <p className="reveal mt-4 max-w-2xl text-neutral-700 md:text-lg">
          Ich helfe Marken, eine klare Geschichte zu erzählen – strategisch, visuell stark und technisch sauber.
        </p>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            { title: 'Branding', text: 'Positionierung, Designsysteme, Guidelines.' },
            { title: 'Websites', text: 'Next.js, Performance, Animationen mit GSAP.' },
            { title: 'Beratung', text: 'Klare Roadmaps, skalierbare Prozesse.' },
          ].map((item) => (
            <div key={item.title} className="reveal rounded-2xl border p-6">
              <h3 className="text-xl font-semibold">{item.title}</h3>
              <p className="mt-2 text-neutral-700">{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
