// src/components/Header.tsx
"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

const LINKS = [
  { href: "#work",    label: "Work" },
  { href: "#services",label: "Services" },
  { href: "#about",   label: "About" },
  { href: "#kontakt", label: "Kontakt" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-[100] transition-colors ${
        scrolled
          ? "bg-white/90 backdrop-blur border-b border-black/10 text-black"
          : "bg-transparent text-white"
      }`}
    >
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 md:px-6">
        {/* Logo / Home */}
        <Link href="#top" className="flex items-center gap-2">
          <span className="inline-block h-8 w-8 rounded bg-[#ff7a00]" aria-hidden />
          <span className="font-semibold">WELL EDGE CREATIVE</span>
        </Link>

        {/* Links (Desktop) */}
        <ul className="hidden md:flex items-center gap-4">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="font-medium hover:opacity-80">
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <a
          href="#kontakt"
          className="rounded-full px-5 py-2 font-semibold bg-[#ff7a00] text-black"
        >
          Book a Call
        </a>
      </nav>
    </header>
  );
}
