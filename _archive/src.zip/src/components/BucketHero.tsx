"use client";

import { useLayoutEffect, useRef } from "react";
import Image from "next/image";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);

export default function BucketHero() {
  const heroRef   = useRef<HTMLElement>(null);
  const pinRef    = useRef<HTMLDivElement>(null);
  const bgRef     = useRef<HTMLDivElement>(null);
  const fgRef     = useRef<HTMLDivElement>(null);
  const bucketRef = useRef<HTMLDivElement>(null);

  // --- TUNING (nur hier drehen) ---
  const FG_VH = 72;          // Foreground weiter nach oben (62–78)
  const BG_VH = 4;           // Background dezent nach unten (3–5)
  const OVERSCAN_VH = 32;    // FG etwas verlängern → keine Naht (28–36)
  const END_FACTOR = 1.38;   // Hero etwas länger halten → Sektion 2 kommt später

  // Eimer
  const BUCKET_SIZE = 1.5;
  const BUCKET_START_VH = -14;
  const BUCKET_TRAVEL_VH = 70;
  const BUCKET_LAG = 0.06;
  const BUCKET_SWING_X = 10;
  const BUCKET_SWING_ROT = 1.1;
  const BUCKET_SWING_DUR = 3.6;

  // Rope (Optik)
  const ROPE_EXTEND = true;
  const ROPE_EXT_VH = 200;
  const ROPE_WIDTH_PX = 3;
  const ROPE_STYLE = "linear-gradient(#ccb, #876)";

  // responsive Eimerhöhe
  const BUCKET_MIN_PX = 260 * BUCKET_SIZE;
  const BUCKET_MID_VH = 50  * BUCKET_SIZE;
  const BUCKET_MAX_PX = 640 * BUCKET_SIZE;
  const bucketHeight = `clamp(${BUCKET_MIN_PX}px, ${BUCKET_MID_VH}vh, ${BUCKET_MAX_PX}px)`;

  const vh = (v: number) =>
    typeof window !== "undefined" ? window.innerHeight * (v / 100) : 0;

  // warten bis Bilder gerendert → dann messen
  const ready = async () => {
    const imgs = Array.from((pinRef.current as HTMLElement).querySelectorAll("img"));
    await Promise.allSettled(
      imgs.map(
        (img) =>
          new Promise<void>((res) => {
            if ((img as HTMLImageElement).complete) return res();
            img.addEventListener("load", () => res(), { once: true });
            img.addEventListener("error", () => res(), { once: true });
          })
      )
    );
    await new Promise((r) => requestAnimationFrame(() => r(null)));
  };

  useLayoutEffect(() => {
    if (!heroRef.current || !pinRef.current || !bgRef.current || !fgRef.current || !bucketRef.current) return;

    let ctx: gsap.Context | null = null;

    (async () => {
      await ready();

      ctx = gsap.context(() => {
        const tl = gsap.timeline({
          scrollTrigger: {
            trigger: heroRef.current!,
            start: "top top",
            end: () => `+=${Math.round(window.innerHeight * END_FACTOR)}`,
            scrub: true,
            pin: pinRef.current!,   // nur inneren Wrapper pinnen
            pinType: "transform",
            pinSpacing: false,      // keine Lücke
            anticipatePin: 1,
            invalidateOnRefresh: true,
          },
        });

        // Parallax
        tl.to(bgRef.current!, { y: () =>  vh(BG_VH),  ease: "none" }, 0);
        tl.to(fgRef.current!, { y: () => -vh(FG_VH),  ease: "none" }, 0);

        // Eimer: runter + schwingen
        tl.to(bucketRef.current!, { y: () => vh(BUCKET_TRAVEL_VH), ease: "none" }, BUCKET_LAG);

        gsap.to(bucketRef.current!, {
          x: BUCKET_SWING_X,
          rotation: BUCKET_SWING_ROT,
          transformOrigin: "top center",
          duration: BUCKET_SWING_DUR,
          ease: "sine.inOut",
          yoyo: true,
          repeat: -1,
        });
      }, pinRef);

      ScrollTrigger.refresh();
    })();

    return () => {
      ctx?.revert();
      ScrollTrigger.kill();
    };
  }, []);

  return (
    <header ref={heroRef} className="relative h-[100vh] bg-black z-0">
      {/* RELATIVER Pin-Wrapper */}
      <div ref={pinRef} className="relative h-full w-full will-change-transform">
        {/* BG */}
        <div ref={bgRef} className="absolute inset-0 z-0 will-change-transform">
          <Image
            src="/well_deep_down_2.jpg"   // muss in /public liegen
            alt=""
            fill
            priority
            className="object-cover opacity-95"
          />
        </div>

        {/* Text */}
        <div className="absolute inset-0 z-20 grid place-items-center text-center px-6">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-6xl font-extrabold leading-tight text-white">
              <span className="text-[#ff7a00]">Story-driven</span> Branding & Webdesign
            </h1>
            <p className="mt-4 text-white/80">
              Klare Strategie, starke Story, spürbares Erlebnis – vom Logo bis zur Website.
            </p>
            <a
              href="#leistungen"
              className="mt-6 inline-block rounded-full bg-[#ff7a00] px-5 py-3 font-semibold text-black"
            >
              Leistungen ansehen
            </a>
          </div>
        </div>

        {/* Bucket */}
        <div
          ref={bucketRef}
          className="absolute left-1/2 z-40 -translate-x-1/2 pointer-events-none will-change-transform"
          style={{ top: `${BUCKET_START_VH}vh`, width: "max-content" }}
          aria-hidden
        >
          {ROPE_EXTEND && (
            <div
              className="absolute left-1/2 -translate-x-1/2"
              style={{
                bottom: "100%",
                height: `${ROPE_EXT_VH}vh`,
                width: `${ROPE_WIDTH_PX}px`,
                background: ROPE_STYLE,
                opacity: 0.8,
              }}
            />
          )}
          <Image
            src="/bucket-rope-long-angled.png"  // muss in /public liegen
            alt=""
            width={0}
            height={0}
            sizes="100vw"
            style={{ height: bucketHeight, width: "auto", display: "block" }}
            priority
          />
        </div>

        {/* FG-Cutout */}
        <div
          ref={fgRef}
          className="pointer-events-none absolute left-0 right-0 top-0 z-50 will-change-transform"
          style={{ height: `calc(100% + ${OVERSCAN_VH}vh)` }}
        >
          <Image
            src="/foreground_Startingpage.png"  // muss in /public liegen
            alt=""
            fill
            priority
            className="object-cover"
          />
        </div>
      </div>
    </header>
  );
}
