// src/app/page.tsx
import Header from "../components/Header";
import BucketHero from "../components/BucketHero";

export default function Home() {
  return (
    <main className="relative">
      {/* Feste Navi ganz oben, liegt über allem */}
      <Header />

      {/* HERO (Eimer + Cutout + Parallax in BucketHero geregelt) */}
      {/* Wichtig: BucketHero sollte <header className="... z-0"> haben */}
      <BucketHero />

      {/* SEKTION 2 — MUSS über dem Hero liegen und weiß sein */}
      <section id="leistungen" className="relative z-[60] bg-white">
        <div className="mx-auto max-w-5xl px-6 py-20 md:py-28">
          <h2 className="text-3xl md:text-4xl font-semibold tracking-tight text-[#ff7a00]">
            Willkommen bei WELL EDGE CREATIVE!
          </h2>
          <p className="mt-4 text-neutral-700 md:text-lg max-w-3xl">
            Ich verbinde Strategie, Gestaltung und Umsetzung. Wir holen das aus deinem Kern,
            was dich wirklich unterscheidet – und bringen es sauber ins Web.
          </p>
        </div>
      </section>

      {/* Platzhalter für weitere weiße Sektionen – immer über dem Hero stapeln */}
      <section id="about" className="relative z-[60] bg-white">
        <div className="mx-auto max-w-5xl px-6 py-20 md:py-28">
          <h2 className="text-2xl md:text-3xl font-semibold">Über mich</h2>
          <p className="mt-4 text-neutral-700">
            Kurzer Introtext …
          </p>
        </div>
      </section>
    </main>
  );
}
