export type Case = {
  slug: string;
  title: string;
  client: string;
  sector: "Retreat" | "Education" | "Healthcare" | "Small Business" | "Music" | "Hospitality";
  year: string;
  role: string[];
  outcome: string;
  summary: string;
  problem: string;
  approach: string;
  result: string;
  site?: string;
  color?: string;
  images: { src: string; alt: string }[];
};

export const cases: Case[] = [
  {
    slug: "brisa-bahia",
    title: "Brisa Bahía — Retreat brand & website",
    client: "Brisa Bahía",
    sector: "Retreat",
    year: "2025",
    role: ["Branding","Logo","Webdesign","Webdev (Next.js, GSAP)"],
    outcome: "Clear offers, premium feel, booking-ready flow.",
    summary: "Story-first brand system and fast, mobile-first website.",
    problem: "Needed a premium presence and a clear path to booking across devices.",
    approach: "Defined positioning and story, created logo suite & visual system, built mobile-first site with smooth scroll depth.",
    result: "Visitors grasp the offer quickly and move confidently toward contact/booking.",
    site: "https://www.brisabahia.com/",
    color: "#0B4216",
    images: [
      { src: "/cases/brisa-bahia/hero.jpg", alt: "Brisa Bahía hero" },
      { src: "/cases/brisa-bahia/mobile.jpg", alt: "Brisa Bahía mobile" },
      { src: "/cases/brisa-bahia/inner.jpg", alt: "Brisa Bahía inner page" },
    ],
  },
  {
    slug: "kikotemaal-kakaw",
    title: "Ki’Kotemaal Kakaw — cultural retreat",
    client: "Ki’Kotemaal Kakaw",
    sector: "Retreat",
    year: "2025",
    role: ["Branding","Logo","Webdesign","Webdev (Next.js, GSAP)"],
    outcome: "Authentic story, consistent visuals, smoother inquiry flow.",
    summary: "Respectful brand presence with clear offers and warm visuals.",
    problem: "Communicate traditions with respect while making offerings easy to understand.",
    approach: "Light brand system, content structure around core experiences, mobile-first layout.",
    result: "Credible first impression; people find what they need and reach out faster.",
    site: "https://www.tripadvisor.com/Attraction_Review-g1065829-d33376309-Reviews-Ki_Kotemaal_Kakaw-San_Juan_la_Laguna_Lake_Atitlan_Solola_Department_Western_Hig.html",
    images: [
      { src: "/cases/kikotemaal-kakaw/hero.jpg", alt: "Ki’Kotemaal hero" },
      { src: "/cases/kikotemaal-kakaw/mobile.jpg", alt: "Ki’Kotemaal mobile" },
    ],
  },
  {
    slug: "ticolingo",
    title: "TicoLingo — language school site polish",
    client: "TicoLingo",
    sector: "Education",
    year: "2024",
    role: ["Webdesign","Graphics","Performance"],
    outcome: "Cleaner conversion path and faster pages.",
    summary: "UI clean-up, content blocks, performance hygiene.",
    problem: "Inconsistent UI and unclear mobile conversion path.",
    approach: "Consolidated components, clarified CTAs, tightened hierarchy, improved speed.",
    result: "More confidence and fewer steps to inquire.",
    images: [
      { src: "/cases/ticolingo/hero.jpg", alt: "TicoLingo hero" },
    ],
  },
  {
    slug: "baycura-intensiv",
    title: "BayCura Intensiv — healthcare brand updates",
    client: "BayCura Intensiv (ex Bayern Intensiv)",
    sector: "Healthcare",
    year: "2023",
    role: ["Branding","Webdesign"],
    outcome: "Stronger credibility and cleaner information architecture.",
    summary: "Light rebrand; tidy web structure.",
    problem: "Name transition and fragmented content reduced clarity.",
    approach: "Refined brand basics, reorganized content, built consistent components.",
    result: "Professional presence that builds trust with families and caregivers.",
    images: [
      { src: "/cases/baycura-intensiv/hero.jpg", alt: "BayCura hero" },
    ],
  },
  {
    slug: "einfach-schee",
    title: "einfach-schee — full brand & site",
    client: "einfach-schee",
    sector: "Small Business",
    year: "2017",
    role: ["Branding","Logo","Webdesign","Webdev"],
    outcome: "Clear identity and website that’s delivered value for years.",
    summary: "End-to-end brand & website as a solo creator.",
    problem: "Needed a clear brand and simple, maintainable website.",
    approach: "Logo & palette, brand kit, clean site structure.",
    result: "Sustained use and recognition over years.",
    images: [
      { src: "/cases/einfach-schee/hero.jpg", alt: "einfach-schee hero" },
    ],
  },
  {
    slug: "lisa-mary",
    title: "Lisa Mary — artist logo",
    client: "Lisa Mary",
    sector: "Music",
    year: "2019",
    role: ["Logo","Branding"],
    outcome: "Distinct mark used across merch and car branding.",
    summary: "Bold logo people recognize.",
    problem: "Artist needed a distinctive, versatile mark.",
    approach: "Iterated monogram/wordmark concepts; tested on merch.",
    result: "Adopted widely; consistent on merch and vehicle.",
    images: [
      { src: "/cases/lisa-mary/logo.jpg", alt: "Lisa Mary logo" },
    ],
  },
  {
    slug: "irish-pub",
    title: "Irish Pub — logo mark",
    client: "Irish Pub",
    sector: "Hospitality",
    year: "2016",
    role: ["Logo"],
    outcome: "Recognizable logo for signage and print.",
    summary: "Classic pub mark with character.",
    problem: "Needed a timeless sign-ready logo.",
    approach: "Heritage shapes, strong contrast, simple forms.",
    result: "Works on signage and small prints.",
    images: [
      { src: "/cases/irish-pub/logo.jpg", alt: "Irish Pub logo" },
    ],
  },
];
