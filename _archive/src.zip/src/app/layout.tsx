// src/app/layout.tsx
import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';

export const metadata: Metadata = {
  title: 'Well Edge Creative | Story-driven Branding & Webdesign',
  description: 'Klare Strategie, starke Story, spürbares Erlebnis – vom Logo bis zur Website.',
  openGraph: {
    title: 'Well Edge Creative',
    description: 'Story-driven Branding & Webdesign',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de" className="scroll-smooth">
      <body className="antialiased body-base">
        {/* Skip to main content for accessibility */}
        <a 
          href="#main" 
          className="sr-only focus:not-sr-only fixed left-4 top-4 z-[200] bg-black text-white px-4 py-2 rounded-lg font-semibold"
        >
          Zum Inhalt springen
        </a>

        {/* Header/Navigation - Fixed at top */}
        <Header />

        {/* Main content */}
        <main id="main">
          {children}
        </main>
      </body>
    </html>
  );
}