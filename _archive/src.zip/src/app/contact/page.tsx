"use client";

import { useState } from "react";

type Segment = "retreat" | "startup" | "smb";
const TO = "jan@well-edge-creative.de"; // <— your email

export default function Contact() {
  const [segment, setSegment] = useState<Segment>("retreat");
  const [form, setForm] = useState({ name:"", email:"", website:"", budget:"", timeline:"", goals:"", extra:"" });

  const update = (k: string) => (e: any) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`New inquiry (${segment}) — Well Edge Creative`);
    const body = encodeURIComponent(
      [
        `Name: ${form.name}`,
        `Email: ${form.email}`,
        `Website: ${form.website}`,
        `Segment: ${segment}`,
        `Budget: ${form.budget}`,
        `Timeline: ${form.timeline}`,
        `Goals: ${form.goals}`,
        form.extra ? `Notes: ${form.extra}` : "",
      ].filter(Boolean).join("\n")
    );
    window.location.href = `mailto:${TO}?subject=${subject}&body=${body}`;
  };

  return (
    <div className="bg-white text-black">
      <section className="mx-auto max-w-3xl px-6 py-20">
        <h1 className="text-4xl md:text-5xl font-extrabold">Let’s talk</h1>
        <p className="mt-3 text-black/70">Free 20-minute intro call. I’ll map your next steps.</p>

        <form onSubmit={submit} className="mt-8 grid gap-5">
          <fieldset className="grid gap-3">
            <legend className="text-sm font-bold tracking-wider" style={{ color:"var(--accent)" }}>Project type</legend>
            <div className="flex flex-wrap gap-3">
              {(["retreat","startup","smb"] as Segment[]).map((s) => (
                <label key={s} className={`cursor-pointer rounded-full border px-4 py-2 ${segment===s?"bg-black text-white border-black":"border-black/20"}`}>
                  <input type="radio" name="segment" value={s} checked={segment===s} onChange={() => setSegment(s)} className="hidden" />
                  {s==="retreat" ? "Retreat Center" : s.toUpperCase()}
                </label>
              ))}
            </div>
          </fieldset>

          <div className="grid gap-4 md:grid-cols-2">
            <input className="rounded-lg border border-black/20 p-3" placeholder="Name" required value={form.name} onChange={update("name")} />
            <input className="rounded-lg border border-black/20 p-3" placeholder="Email" type="email" required value={form.email} onChange={update("email")} />
          </div>

          <input className="rounded-lg border border-black/20 p-3" placeholder="Website (if any)" value={form.website} onChange={update("website")} />
          <div className="grid gap-4 md:grid-cols-2">
            <input className="rounded-lg border border-black/20 p-3" placeholder="Budget (range)" value={form.budget} onChange={update("budget")} />
            <input className="rounded-lg border border-black/20 p-3" placeholder="Timeline (e.g. 6–8 weeks)" value={form.timeline} onChange={update("timeline")} />
          </div>
          <textarea className="rounded-lg border border-black/20 p-3" rows={5} placeholder="Goals / What would success look like?" value={form.goals} onChange={update("goals")} />
          <textarea className="rounded-lg border border-black/20 p-3" rows={3} placeholder="Anything else I should know?" value={form.extra} onChange={update("extra")} />

          <button className="mt-2 inline-block px-5 py-3 text-black font-semibold rounded-full" style={{ background:"var(--accent)" }}>Send</button>
        </form>
      </section>
    </div>
  );        
}
